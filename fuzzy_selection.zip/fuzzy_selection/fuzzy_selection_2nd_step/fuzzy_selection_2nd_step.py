#THIS SCRIPT MUST BE APPLIED ONLY AFTER "myfuzzyselection" SCRIPT 
from gimpfu import *

def myfuzzyselection2ndstep(img, layer):

	#Define what should be "undone" - even if it doesn't sem to work
    pdb.gimp_image_undo_group_start(img)
	#progress bar
    gimp.progress_init("Performing fuzzy selection - 2nd step" + layer.name + "...")

    #We wanted to move "left-to-right and "up-to-down" -> so we used (y,x) reference to retrieve pixel values (because GIMP references pixels in this UNUSUAL - AT LEAST IT'S UNUSUAL FOR US - WAY)
    for x in range(layer.height):
        gimp.progress_update(float(x) / float(layer.height))#some special effects: the update of the progress bar ^_^
        for y in range(layer.width):
            pixel=layer.get_pixel(y,x)[0]
            if((pixel!=0) and y!=(layer.width-1)):  #we found an "ex-white" pixel, let's check if it has a neighbour with a different color (belonging to a different cluster)
                right_pix = layer.get_pixel(y+1,x)[0]#retrieve the value of the pixel on the rightt
                if((right_pix!=0) and (pixel!=right_pix)): #also the pixel on the right was white before, but had been assigned to a different cluster
                    layer.set_pixel(y,x,(right_pix,))#assign the color of the cluster the right pixel belongs to to our current pixel (later, if the upper pixel is "white" too - that's if it's not black -, we will reassign to our current pixel the color of the cluster the upper pixel belongs to)
                    #change recursively the values of the pixels below the current pixel - they have the same "wrong" label
                    if(x<(layer.height-1)):#if there are still other rows below...
                        row = x+1
                        below_pix=layer.get_pixel(y,row)[0]
                        #a "recursive" procedure follows...
                        while(below_pix!=0):#while our below pixel is an "ex-white" pixel (belonging to the same wrong cluster as the current pixel)...
                            layer.set_pixel(y,row,(right_pix,))
                            if(row<(layer.height-1)):
                                row=row+1
                                below_pix = layer.get_pixel(y,row)[0]
                            else:
                                break#let's get out of the while cycle - we reached the last row
	# Update the layer
	layer.update(0, 0, layer.width, layer.height)
    pdb.gimp_image_undo_group_end(img)
	# End progress.
    pdb.gimp_progress_end()
    return True

register(
         "python-fu-myfuzzyselection-2nd-step",
         N_("Fuzzy selection - 2nd step"),
         "Two step fuzzy selection.",
         "Yana",
         "Yana",
         "21/04/2020",
         N_("_My fuzzyselection - 2nd step"),
         "GRAY",
         [
          (PF_IMAGE, "image",       "Input GRAYSCALE image", None),
          (PF_DRAWABLE, "drawable", "Input GRAYSCALE drawable", None),
          ],
         [],
         myfuzzyselection2ndstep,
         menu="<Image>/Filters/My plug in menu",
         domain=("gimp20-python", gimp.locale_directory)
         )
main()
