#IN ORDER TO MAKE THIS SCIPT WORK, APPLY TRESHOLDING ON THE IMAGE PROVIDED TOGETHER WITH THIS CODE - WE NEED TO HAVE ONLY 0 OR 255 INTENSITY PIXELS IN OUR INPUT IMAGE
#THE IMAGE THAT HAS BEEN PROVIDED IS 8X8...IT NEEDS TO BE ZOOMED FOR A BETTER EXPERIENCE :)
from gimpfu import *

L=256

def myfuzzyselection(img, layer):

	#Define what should be "undone" - even if it doesn't sem to work
    pdb.gimp_image_undo_group_start(img)
	#progress bar
    gimp.progress_init("Performing fuzzy selection " + layer.name + "...")

    count = 1
    #We wanted to move "left-to-right and "up-to-down" -> so we used (y,x) reference to retrieve pixel values (because GIMP references pixels in this UNUSUAL - AT LEAST IT'S UNUSUAL FOR US - WAY)
    for x in range(layer.height):
        gimp.progress_update(float(x) / float(layer.height))#some special effects: the update of the progress bar ^_^
        for y in range(layer.width):
            pixel=layer.get_pixel(y,x)[0]
            if(pixel==L-1):  #we found a white pixel, let's assign to it a cluster color...
                if(y>0):
                    left_pix = layer.get_pixel(y-1,x)[0]#retrieve the value of the pixel on the left
                    if(left_pix!=0):
                        layer.set_pixel(y,x,(left_pix,))#assign the color of the cluster the left pixel belongs to to our current pixel (later, if the upper pixel is "white" too - that's if it's not black -, we will reassign to our current pixel the color of the cluster the upper pixel belongs to)
                if(x>0):#if there exist an upper pixel...
                    upper_pix = layer.get_pixel(y,x-1)[0]#retrieve the value of the pixel that is right above our current pixel
                    if(upper_pix!=0):
                        layer.set_pixel(y,x,(upper_pix,))#assign the color of the cluster the pixel right above our current pixel belongs to to our current pixel - in this case we do overwrite the color of the pixel on the left in case it has been assigned to our current pixel in the previous steps

                #new cluster - compute a new color
                if((x==0 and y==0) or (x>0 and y>0 and upper_pix==0 and left_pix==0) or (y==0 and upper_pix==0) or (x==0 and left_pix==0)):#the cases in which we assign our pixel to a new cluster
                    new_value = count*20%L#actually this formula was tailored "ad hoc" to perform the first step of the fuzzy selection (by colouring) on a specific image (8x8);  #spoiler:we will obtain 8 clusters at the end
                    layer.set_pixel(y,x,(new_value,))
                    count+=1#increment the "label number" - that will be used by the next cluster


	# Update the layer
	layer.update(0, 0, layer.width, layer.height)
    pdb.gimp_image_undo_group_end(img)
	# End progress.
    pdb.gimp_progress_end()
    return True

register(
         "python-fu-myfuzzyselection",
         N_("Fuzzy selection"),
         "Two step fuzzy selection.",
         "Yana",
         "Yana",
         "21/04/2020",
         N_("_My fuzzyselection"),
         "GRAY",
         [
          (PF_IMAGE, "image",       "Input GRAYSCALE image", None),
          (PF_DRAWABLE, "drawable", "Input GRAYSCALE drawable", None),
          ],
         [],
         myfuzzyselection,
         menu="<Image>/Filters/My plug in menu",
         domain=("gimp20-python", gimp.locale_directory)
         )
main()
