from gimpfu import *

L = 256#number of intensity levels

#the following subroutine computes the cumulative distribution function (cdf)
#of intensity levels and outputs a tuple consisting of cdf(minimum intensity
#value) and an array cdf[] of size L where we store cdf(v) for each v in [0,255]
def compute_cumulative_distribution(layer,L):

	cdf = [0] * L#create an array of size L filled with 0s
	for x in range(layer.width):
		for y in range(layer.height):
			value=layer.get_pixel(x,y)[0]
			cdf[value]+=1#increment by one the count of pixels having the
			 			 #intensity #value

	#cumulative sum
	for i in range(1,L):
		cdf[i]+=cdf[i-1]

	#getting minimum cdf before applying subtraction
	i=0
	cdf_min=0
	while(cdf_min==0):
		cdf_min=cdf[i]
		++i
	return (cdf_min,cdf)

def ourequalization(img, layer):
	#Define what should be "undone" - even if it doesn't seem to work...
	pdb.gimp_image_undo_group_start(img)
	#Progress bar
	gimp.progress_init("Equalizzazione " + layer.name + "...")

	#We can work on an RGB image too: we will convert it to a grayscale image ->
	if(not pdb.gimp_drawable_is_gray(layer)):
		pdb.gimp_image_convert_grayscale(img)

	#already explained
	cdf_min, cdf = compute_cumulative_distribution(layer, L)

	#update the values of the pixels
	for x in range(layer.width):
		gimp.progress_update(float(x) / float(layer.width))#some special effects: the update of the progress bar ^_^
		for y in range(layer.height):
			pixel=layer.get_pixel(x,y)[0]
			new_value = int(round((cdf[pixel]- cdf_min)*(L-1)/(layer.width*layer.height-1)))#the formula of equalization
			layer.set_pixel(x,y,(new_value,))

	# Update the layer
	layer.update(0, 0, layer.width, layer.height)
	pdb.gimp_image_undo_group_end(img)
	# End progress.
	pdb.gimp_progress_end()
	return True

register(
         "python-fu-myequalization",
         N_("Equalizzazione"),
         "Si lavora con la distribuzione cumulativa.",
         "Yana&KaiserSource",
         "Yana&KaiserSource",
         "16/04/2020",
         N_("_Our equalization"),
         "GRAY, RGB",
         [
          (PF_IMAGE, "image",       "Input RGB or GRAYSCALE image", None),
          (PF_DRAWABLE, "drawable", "Input RGB or GRAYSCALE drawable", None),
          ],
         [],
         ourequalization,
         menu="<Image>/Filters/My plug in menu",
         domain=("gimp20-python", gimp.locale_directory)
         )
main()
